<?php
include 'db.php';
$message = '';

// For demonstration simplicity, we assume a hardcoded employer_id = 1 (or make sure you have an employer record in your table)
$employer_id = 1; 

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $job_title = $conn->real_escape_string($_POST['job_title']);
    $job_category = $conn->real_escape_string($_POST['job_category']);
    $job_type = $conn->real_escape_string($_POST['job_type']);
    $location = $conn->real_escape_string($_POST['location']);
    $salary_range = $conn->real_escape_string($_POST['salary_range']);
    $job_description = $conn->real_escape_string($_POST['job_description']);

    $sql = "INSERT INTO jobs (employer_id, job_title, job_category, job_type, location, salary_range, job_description) 
            VALUES ($employer_id, '$job_title', '$job_category', '$job_type', '$location', '$salary_range', '$job_description')";

    if ($conn->query($sql) === TRUE) {
        $message = "Job posted successfully!";
    } else {
        $message = "Error posting job: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Post a Job - JobBoard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

    <div class="container mt-5 mb-5" style="max-width: 700px;">
        <a href="index.php" class="btn btn-secondary btn-sm mb-3">&larr; Back to Home</a>
        <div class="card shadow-sm p-4">
            <h2 class="mb-4">Post a New Job Opening</h2>
            
            <?php if(!empty($message)): ?>
                <div class="alert alert-info"><?php echo $message; ?></div>
            <?php endif; ?>

            <form action="post_job.php" method="POST">
                <div class="mb-3">
                    <label class="form-label">Job Title</label>
                    <input type="text" name="job_title" class="form-control" placeholder="e.g. Senior PHP Developer" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Job Category</label>
                    <input type="text" name="job_category" class="form-control" placeholder="e.g. Software Development" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Job Type</label>
                    <select name="job_type" class="form-select" required>
                        <option value="Full-Time">Full-Time</option>
                        <option value="Part-Time">Part-Time</option>
                        <option value="Remote">Remote</option>
                        <option value="Contract">Contract</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Location</label>
                    <input type="text" name="location" class="form-control" placeholder="e.g. New York, NY or Worldwide" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Salary Range</label>
                    <input type="text" name="salary_range" class="form-control" placeholder="e.g. $80,000 - $100,000" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Job Description</label>
                    <textarea name="job_description" rows="6" class="form-control" placeholder="Describe the responsibilities and requirements..." required></textarea>
                </div>
                <button type="submit" class="btn btn-dark w-100">Publish Job</button>
            </form>
        </div>
    </div>

</body>
</html>