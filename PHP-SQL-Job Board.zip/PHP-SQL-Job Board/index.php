<?php
include 'db.php';

$search_keyword = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';
$search_location = isset($_GET['location']) ? $conn->real_escape_string($_GET['location']) : '';

$sql = "SELECT jobs.*, employers.company_name FROM jobs 
        JOIN employers ON jobs.employer_id = employers.employer_id 
        WHERE (jobs.job_title LIKE '%$search_keyword%' OR jobs.job_description LIKE '%$search_keyword%') 
        AND jobs.location LIKE '%$search_location%' 
        ORDER BY jobs.created_at DESC";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Online Job Board</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
        <div class="container">
            <a class="navbar-brand" href="index.php">JobBoard</a>
            <div>
                <a href="post_job.php" class="btn btn-outline-light btn-sm me-2">Post a Job</a>
                <a href="employer_login.php" class="btn btn-primary btn-sm">Employer Login</a>
            </div>
        </div>
    </nav>

    <div class="container">
        <!-- Search Section -->
        <div class="row mb-4">
            <div class="col-md-12">
                <form action="index.php" method="GET" class="row g-3 bg-white p-4 rounded shadow-sm">
                    <div class="col-md-5">
                        <input type="text" name="search" class="form-control" placeholder="Job title, keyword, or company" value="<?php echo htmlspecialchars($search_keyword); ?>">
                    </div>
                    <div class="col-md-5">
                        <input type="text" name="location" class="form-control" placeholder="City or remote" value="<?php echo htmlspecialchars($search_location); ?>">
                    </div>
                    <div class="col-md-2">
                        <button type="submit" class="btn btn-dark w-100">Search Jobs</button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Job Listings -->
        <h2 class="mb-4">Latest Job Openings</h2>
        <div class="row">
            <?php if ($result->num_rows > 0): ?>
                <?php while($row = $result->fetch_assoc()): ?>
                    <div class="col-md-12 mb-3">
                        <div class="card shadow-sm">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <h4 class="card-title text-primary"><?php echo htmlspecialchars($row['job_title']); ?></h4>
                                    <span class="badge bg-secondary"><?php echo htmlspecialchars($row['job_type']); ?></span>
                                </div>
                                <h6 class="card-subtitle mb-2 text-muted"><?php echo htmlspecialchars($row['company_name']); ?> &bull; <i class="bi bi-geo-alt"></i> <?php echo htmlspecialchars($row['location']); ?></h6>
                                <p class="card-text"><?php echo nl2br(htmlspecialchars(substr($row['job_description'], 0, 200))); ?>...</p>
                                <p class="text-success fw-bold">Salary: <?php echo htmlspecialchars($row['salary_range']); ?></p>
                                <a href="job_details.php?id=<?php echo $row['job_id']; ?>" class="btn btn-outline-primary btn-sm">View Details & Apply</a>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="col-md-12">
                    <div class="alert alert-warning">No jobs found matching your criteria.</div>
                </div>
            <?php endif; ?>
        </div>
    </div>

</body>
</html>