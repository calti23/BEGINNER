<?php
include 'db.php';

$job_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$success_message = '';
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $applicant_name = $conn->real_escape_string($_POST['applicant_name']);
    $applicant_email = $conn->real_escape_string($_POST['applicant_email']);
    $resume_text = $conn->real_escape_string($_POST['resume_text']);

    if (!empty($applicant_name) && !empty($applicant_email) && !empty($resume_text)) {
        $insert_sql = "INSERT INTO applications (job_id, applicant_name, applicant_email, resume_text) VALUES ($job_id, '$applicant_name', '$applicant_email', '$resume_text')";
        if ($conn->query($insert_sql) === TRUE) {
            $success_message = "Your application has been submitted successfully!";
        } else {
            $error_message = "Error submitting application. Please try again.";
        }
    } else {
        $error_message = "Please fill in all fields.";
    }
}

$sql = "SELECT jobs.*, employers.company_name FROM jobs JOIN employers ON jobs.employer_id = employers.employer_id WHERE jobs.job_id = $job_id";
$result = $conn->query($sql);

if ($result->num_rows == 0) {
    die("Job listing not found.");
}
$job = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo htmlspecialchars($job['job_title']); ?> - JobBoard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

    <div class="container mt-5">
        <a href="index.php" class="btn btn-secondary btn-sm mb-3">&larr; Back to Listings</a>

        <div class="row">
            <div class="col-md-8">
                <div class="card shadow-sm p-4 mb-4">
                    <h2 class="text-primary"><?php echo htmlspecialchars($job['job_title']); ?></h2>
                    <h5 class="text-muted"><?php echo htmlspecialchars($job['company_name']); ?></h5>
                    <hr>
                    <p><strong>Location:</strong> <?php echo htmlspecialchars($job['location']); ?></p>
                    <p><strong>Job Type:</strong> <?php echo htmlspecialchars($job['job_type']); ?></p>
                    <p><strong>Category:</strong> <?php echo htmlspecialchars($job['job_category']); ?></p>
                    <p><strong>Salary:</strong> <?php echo htmlspecialchars($job['salary_range']); ?></p>
                    <hr>
                    <h4>Job Description</h4>
                    <p><?php echo nl2br(htmlspecialchars($job['job_description'])); ?></p>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card shadow-sm p-4">
                    <h4>Apply for this Job</h4>
                    <?php if(!empty($success_message)): ?>
                        <div class="alert alert-success"><?php echo $success_message; ?></div>
                    <?php endif; ?>
                    <?php if(!empty($error_message)): ?>
                        <div class="alert alert-danger"><?php echo $error_message; ?></div>
                    <?php endif; ?>

                    <form action="job_details.php?id=<?php echo $job_id; ?>" method="POST">
                        <div class="mb-3">
                            <label class="form-label">Full Name</label>
                            <input type="text" name="applicant_name" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Email Address</label>
                            <input type="email" name="applicant_email" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Cover Letter / Resume Summary</label>
                            <textarea name="resume_text" rows="5" class="form-control" placeholder="Write about your experience..." required></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary w-100">Submit Application</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

</body>
</html>